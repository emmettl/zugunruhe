import { defineConfig } from 'vite';
import { fileURLToPath } from 'node:url';
export default defineConfig({build:{rolldownOptions:{input:{
  layers:fileURLToPath(new URL('./index.html',import.meta.url)),
  network:fileURLToPath(new URL('./network.html',import.meta.url)),
}}}});
